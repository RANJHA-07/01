import { useState, type FormEvent } from "react";
import { motion } from "framer-motion";
import { useAudio } from "@/context/AudioContext";

type Props = { onLogin: (name: string) => void };

/** A dreamy login gate that leads into the proposal. */
export default function LoginPage({ onLogin }: Props) {
  const { play } = useAudio();
  const [name, setName] = useState(
    () => localStorage.getItem("fwy_username") || ""
  );
  const [password, setPassword] = useState("");
  const [remember, setRemember] = useState(!!localStorage.getItem("fwy_username"));
  const [show, setShow] = useState(false);
  const [loading, setLoading] = useState(false);

  const submit = (e: FormEvent) => {
    e.preventDefault();
    const finalName = name.trim() || "My Love";
    if (remember) localStorage.setItem("fwy_username", finalName);
    else localStorage.removeItem("fwy_username");
    play(); // user gesture — start the music
    setLoading(true);
    setTimeout(() => onLogin(finalName), 2400);
  };

  return (
    <motion.div
      key="login"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0, scale: 1.04 }}
      transition={{ duration: 0.6 }}
      className="relative flex min-h-screen items-center justify-center px-5 py-10"
    >
      <motion.div
        initial={{ opacity: 0, y: 40, scale: 0.96 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ duration: 0.7, ease: "easeOut" }}
        className="glass-strong relative w-full max-w-md rounded-[2rem] p-8 sm:p-10"
      >
        {/* glowing heart emblem */}
        <div className="mb-2 flex justify-center">
          <motion.div
            animate={{ scale: [1, 1.18, 1] }}
            transition={{ duration: 1.3, repeat: Infinity }}
            className="flex h-20 w-20 items-center justify-center rounded-full bg-gradient-to-br from-blush-400 to-rose-gold text-4xl shadow-xl shadow-blush-300"
          >
            ❤️
          </motion.div>
        </div>

        <h1 className="text-center font-script text-5xl text-gradient">Forever With You</h1>
        <p className="mt-1 text-center font-dancing text-xl text-rose-gold">
          A little door into my heart 💕
        </p>

        <form onSubmit={submit} className="mt-7 space-y-4">
          <div>
            <label className="mb-1 block text-sm font-semibold text-blush-700">
              Username
            </label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Your sweet name"
              className="w-full rounded-2xl border border-white/70 bg-white/60 px-4 py-3 text-blush-800 outline-none transition placeholder:text-blush-300 focus:border-blush-400 focus:ring-2 focus:ring-blush-300/60"
            />
          </div>

          <div>
            <label className="mb-1 block text-sm font-semibold text-blush-700">
              Password
            </label>
            <div className="relative">
              <input
                type={show ? "text" : "password"}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="The key to my heart"
                className="w-full rounded-2xl border border-white/70 bg-white/60 px-4 py-3 pr-12 text-blush-800 outline-none transition placeholder:text-blush-300 focus:border-blush-400 focus:ring-2 focus:ring-blush-300/60"
              />
              <button
                type="button"
                onClick={() => setShow((s) => !s)}
                aria-label={show ? "Hide password" : "Show password"}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-xl"
              >
                {show ? "🙈" : "👁️"}
              </button>
            </div>
          </div>

          <label className="flex cursor-pointer items-center gap-2 text-sm font-medium text-blush-700">
            <input
              type="checkbox"
              checked={remember}
              onChange={(e) => setRemember(e.target.checked)}
              className="h-4 w-4 accent-blush-500"
            />
            Remember me forever
          </label>

          <motion.button
            type="submit"
            whileHover={{ scale: 1.04 }}
            whileTap={{ scale: 0.96 }}
            disabled={loading}
            className="group relative w-full overflow-hidden rounded-2xl bg-gradient-to-r from-blush-500 via-blush-400 to-rose-gold py-3.5 text-lg font-bold text-white shadow-xl shadow-blush-300/60 transition disabled:opacity-90"
          >
            <span className="relative z-10">
              {loading ? "Opening…" : "Enter My Heart ❤️"}
            </span>
            <span className="absolute inset-0 -translate-x-full bg-white/30 transition-transform duration-700 group-hover:translate-x-full" />
          </motion.button>
        </form>

        <p className="mt-5 text-center text-xs text-blush-700/70">
          (Any name & password works — this heart is always open for you)
        </p>
      </motion.div>

      {/* romantic loading overlay */}
      {loading && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-blush-50/80 backdrop-blur-md"
        >
          <motion.div
            animate={{ scale: [1, 1.25, 1] }}
            transition={{ duration: 0.9, repeat: Infinity }}
            className="text-7xl"
          >
            💗
          </motion.div>
          <p className="mt-6 font-dancing text-3xl text-blush-600">
            Opening my heart for you…
          </p>
          <div className="mt-4 h-1.5 w-48 overflow-hidden rounded-full bg-blush-200">
            <motion.div
              className="h-full bg-gradient-to-r from-blush-500 to-rose-gold"
              initial={{ width: "0%" }}
              animate={{ width: "100%" }}
              transition={{ duration: 2.3, ease: "easeInOut" }}
            />
          </div>
        </motion.div>
      )}
    </motion.div>
  );
}

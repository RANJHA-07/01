import { useEffect, useState } from "react";
import { motion } from "framer-motion";

// The day our forever began 💕 (change to your own special date)
const START = new Date("2024-04-16T18:00:00");

function diff(now: number) {
  const d = Math.max(0, now - START.getTime());
  return {
    days: Math.floor(d / 86400000),
    hours: Math.floor(d / 3600000) % 24,
    minutes: Math.floor(d / 60000) % 60,
    seconds: Math.floor(d / 1000) % 60,
  };
}

function Unit({ value, label }: { value: number; label: string }) {
  return (
    <div className="flex flex-col items-center">
      <div className="glass min-w-[64px] rounded-2xl px-3 py-3 sm:min-w-[88px] sm:px-5 sm:py-4">
        <span className="block bg-gradient-to-b from-blush-600 to-blush-500 bg-clip-text text-center font-serif text-3xl font-bold text-transparent tabular-nums sm:text-5xl">
          {String(value).padStart(2, "0")}
        </span>
      </div>
      <span className="mt-2 text-xs font-semibold uppercase tracking-[0.18em] text-rose-gold sm:text-sm">
        {label}
      </span>
    </div>
  );
}

/** Counts the time we've spent together, ticking every second. */
export default function LoveCountdown() {
  const [time, setTime] = useState(() => diff(Date.now()));

  useEffect(() => {
    const id = setInterval(() => setTime(diff(Date.now())), 1000);
    return () => clearInterval(id);
  }, []);

  return (
    <motion.section
      initial={{ opacity: 0, y: 40 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, amount: 0.3 }}
      transition={{ duration: 0.7 }}
      className="relative mx-auto max-w-4xl px-5 py-20 text-center sm:py-28"
    >
      <p className="font-dancing text-2xl text-rose-gold sm:text-3xl">
        Every second with you
      </p>
      <h2 className="mt-1 font-script text-4xl text-gradient sm:text-6xl">
        is my favourite time
      </h2>
      <p className="mx-auto mt-4 max-w-md text-sm text-blush-700/80 sm:text-base">
        Counting every heartbeat we've shared since the day you walked into my
        world.
      </p>

      <div className="mt-10 flex items-end justify-center gap-3 sm:gap-5">
        <Unit value={time.days} label="Days" />
        <span className="pb-9 font-serif text-3xl text-blush-300 sm:text-5xl">:</span>
        <Unit value={time.hours} label="Hours" />
        <span className="pb-9 font-serif text-3xl text-blush-300 sm:text-5xl">:</span>
        <Unit value={time.minutes} label="Minutes" />
        <span className="pb-9 font-serif text-3xl text-blush-300 sm:text-5xl">:</span>
        <Unit value={time.seconds} label="Seconds" />
      </div>
    </motion.section>
  );
}

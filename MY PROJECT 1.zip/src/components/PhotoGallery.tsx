
import { useCallback, useEffect, useState, type SyntheticEvent } from "react";
import { AnimatePresence, motion } from "framer-motion";

import photo1 from "@/assets/photo1.jpg";
import photo2 from "@/assets/photo2.jpg";
import photo3 from "@/assets/photo3.jpg";
import photo4 from "@/assets/photo4.jpg";
import photo5 from "@/assets/photo5.jpg";
import photo6 from "@/assets/photo6.jpg";

type Photo = { src: string; caption: string; tilt: number };

// Pretty fallback if a remote photo can't load.
const FALLBACK =
  "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='400' height='533'%3E%3Cdefs%3E%3ClinearGradient id='g' x1='0' y1='0' x2='1' y2='1'%3E%3Cstop offset='0' stop-color='%23ffd6e6'/%3E%3Cstop offset='1' stop-color='%23ff9ec4'/%3E%3C/linearGradient%3E%3C/defs%3E%3Crect width='400' height='533' fill='url(%23g)'/%3E%3Ctext x='50%25' y='50%25' font-size='130' text-anchor='middle' dominant-baseline='central'%3E%F0%9F%92%97%3C/text%3E%3C/svg%3E";

const onImgError = (e: SyntheticEvent<HTMLImageElement>) => {
  const img = e.currentTarget;
  if (img.src !== FALLBACK) img.src = FALLBACK;
};

const PHOTOS: Photo[] = [
  {
    src: photo1,
    caption: "Where our story began",
    tilt: -5,
  },
  {
    src: photo2,
    caption: "Lost in you",
    tilt: 4,
  },
  {
    src: photo3,
    caption: "Golden together",
    tilt: -3,
  },
  {
    src: photo4,
    caption: "By the still water",
    tilt: 5,
  },
  {
    src: photo5,
    caption: "Sunsets & you",
    tilt: -4,
  },
  {
    src: photo6,
    caption: "Two hearts, one soul",
    tilt: 3,
  },
];





/** Romantic polaroid gallery with hover animations and a lightbox viewer. */
export default function PhotoGallery() {
  const [active, setActive] = useState<number | null>(null);

  const close = useCallback(() => setActive(null), []);
  const next = useCallback(
    () => setActive((i) => (i === null ? i : (i + 1) % PHOTOS.length)),
    []
  );
  const prev = useCallback(
    () =>
      setActive((i) => (i === null ? i : (i - 1 + PHOTOS.length) % PHOTOS.length)),
    []
  );

  useEffect(() => {
    if (active === null) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") close();
      if (e.key === "ArrowRight") next();
      if (e.key === "ArrowLeft") prev();
    };
    window.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [active, close, next, prev]);

  return (
    <section className="relative mx-auto max-w-6xl px-5 py-20 sm:py-28">
      <div className="text-center">
        <p className="font-dancing text-2xl text-rose-gold sm:text-3xl">
          Moments frozen in time
        </p>
        <h2 className="mt-1 font-script text-4xl text-gradient sm:text-6xl">
          Our Little Gallery
        </h2>
      </div>

      <div className="mt-14 grid grid-cols-2 gap-6 sm:grid-cols-3 lg:gap-8">
        {PHOTOS.map((p, i) => (
          <motion.button
            key={p.src}
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.2 }}
            transition={{ duration: 0.5, delay: (i % 3) * 0.1 }}
            whileHover={{ y: -10, rotate: 0, scale: 1.04 }}
            onClick={() => setActive(i)}
            className="group relative block bg-white p-2 pb-4 shadow-xl"
            style={{ rotate: `${p.tilt}deg` }}
          >
            <div className="aspect-[3/4] overflow-hidden bg-blush-100">
              <img
                src={p.src}
                alt={p.caption}
                loading="lazy"
                onError={onImgError}
                className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-110"
              />
            </div>
            <p className="mt-3 text-center font-dancing text-lg text-blush-700 sm:text-xl">
              {p.caption}
            </p>
          </motion.button>
        ))}
      </div>

      <AnimatePresence>
        {active !== null && (
          <motion.div
            className="fixed inset-0 z-[70] flex items-center justify-center p-4"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={close}
          >
            <div className="absolute inset-0 bg-wine/50 backdrop-blur-md" />
            <button
              onClick={close}
              aria-label="Close"
              className="absolute right-5 top-5 z-20 flex h-11 w-11 items-center justify-center rounded-full bg-white/80 text-xl text-blush-600 transition hover:scale-110"
            >
              ✕
            </button>
            <button
              onClick={(e) => {
                e.stopPropagation();
                prev();
              }}
              aria-label="Previous"
              className="absolute left-3 z-20 flex h-12 w-12 items-center justify-center rounded-full bg-white/80 text-2xl text-blush-600 transition hover:scale-110 sm:left-6"
            >
              ‹
            </button>
            <button
              onClick={(e) => {
                e.stopPropagation();
                next();
              }}
              aria-label="Next"
              className="absolute right-3 z-20 flex h-12 w-12 items-center justify-center rounded-full bg-white/80 text-2xl text-blush-600 transition hover:scale-110 sm:right-6"
            >
              ›
            </button>

            <motion.figure
              key={active}
              initial={{ opacity: 0, scale: 0.85, rotate: -2 }}
              animate={{ opacity: 1, scale: 1, rotate: 0 }}
              exit={{ opacity: 0, scale: 0.9 }}
              transition={{ type: "spring", stiffness: 240, damping: 24 }}
              onClick={(e) => e.stopPropagation()}
              className="relative z-10 w-full max-w-md bg-white p-3 pb-6 shadow-2xl"
            >
              <div className="aspect-[3/4] overflow-hidden bg-blush-100">
                <img
                  src={PHOTOS[active].src}
                  alt={PHOTOS[active].caption}
                  onError={onImgError}
                  className="h-full w-full object-cover"
                />
              </div>
              <figcaption className="mt-3 text-center font-dancing text-2xl text-blush-700">
                {PHOTOS[active].caption}
              </figcaption>
            </motion.figure>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
}

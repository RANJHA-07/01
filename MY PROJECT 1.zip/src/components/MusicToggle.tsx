import { useAudio } from "@/context/AudioContext";

/** Floating play/pause control for the romantic background music. */
export default function MusicToggle() {
  const { playing, toggle } = useAudio();
  return (
    <button
      onClick={toggle}
      aria-label={playing ? "Pause music" : "Play music"}
      className="group fixed bottom-5 right-5 z-50 flex h-14 w-14 items-center justify-center rounded-full glass-strong text-2xl transition-transform duration-300 hover:scale-110 active:scale-95"
    >
      {!playing && (
        <span className="absolute inset-0 rounded-full animate-pulse-glow" />
      )}
      <span className="relative">
        {playing ? (
          <svg viewBox="0 0 24 24" className="h-6 w-6" fill="#f43f78">
            <rect x="6" y="5" width="4" height="14" rx="1.3" />
            <rect x="14" y="5" width="4" height="14" rx="1.3" />
          </svg>
        ) : (
          <svg viewBox="0 0 24 24" className="h-6 w-6" fill="#f43f78">
            <path d="M8 5.5v13a1 1 0 0 0 1.54.84l9.5-6.5a1 1 0 0 0 0-1.68l-9.5-6.5A1 1 0 0 0 8 5.5z" />
          </svg>
        )}
      </span>
      <span className="pointer-events-none absolute right-16 whitespace-nowrap rounded-full glass px-3 py-1 text-xs font-semibold text-blush-700 opacity-0 transition-opacity duration-300 group-hover:opacity-100">
        {playing ? "Pause melody" : "Play our song"}
      </span>
    </button>
  );
}

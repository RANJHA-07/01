import { useState, type CSSProperties } from "react";
import { AnimatePresence, motion } from "framer-motion";

const PETALS = Array.from({ length: 22 });

/** Hidden "Open Secret Letter" button with a petal-falling emotional popup. */
export default function SecretLetter() {
  const [open, setOpen] = useState(false);

  return (
    <section className="relative mx-auto max-w-3xl px-5 py-20 text-center sm:py-28">
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        whileInView={{ opacity: 1, scale: 1 }}
        viewport={{ once: true, amount: 0.4 }}
        transition={{ duration: 0.6 }}
        className="flex flex-col items-center"
      >
        <span className="mb-4 inline-block animate-floaty text-5xl">💌</span>
        <p className="font-dancing text-2xl text-rose-gold sm:text-3xl">
          psst… I kept one more thing for you
        </p>
        <h2 className="mb-6 font-script text-4xl text-gradient sm:text-5xl">
          A Secret Letter
        </h2>
        <button
          onClick={() => setOpen(true)}
          className="group relative overflow-hidden rounded-full bg-gradient-to-r from-blush-500 via-blush-400 to-rose-gold px-8 py-4 font-semibold text-white shadow-xl transition-transform duration-300 hover:scale-105 active:scale-95"
        >
          <span className="relative z-10">Open Secret Letter 💌</span>
          <span className="absolute inset-0 -translate-x-full bg-white/30 transition-transform duration-700 group-hover:translate-x-full" />
        </button>
      </motion.div>

      <AnimatePresence>
        {open && (
          <motion.div
            className="fixed inset-0 z-[70] flex items-center justify-center p-4"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setOpen(false)}
          >
            <div className="absolute inset-0 bg-wine/40 backdrop-blur-sm" />

            {/* falling rose petals */}
            {PETALS.map((_, i) => {
              const left = Math.random() * 100;
              const delay = Math.random() * 4;
              const dur = 5 + Math.random() * 5;
              const drift = (Math.random() - 0.5) * 200;
              const size = 10 + Math.random() * 14;
              return (
                <span
                  key={i}
                  className="petal"
                  style={
                    {
                      left: `${left}%`,
                      width: size,
                      height: size,
                      animationDelay: `${delay}s`,
                      animationDuration: `${dur}s`,
                      "--drift": `${drift}px`,
                    } as CSSProperties
                  }
                />
              );
            })}

            <motion.div
              onClick={(e) => e.stopPropagation()}
              initial={{ opacity: 0, y: 40, scale: 0.92 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 20, scale: 0.95 }}
              transition={{ type: "spring", stiffness: 220, damping: 22 }}
              className="glass-strong relative z-10 max-h-[85vh] w-full max-w-lg overflow-hidden rounded-3xl"
            >
              <button
                onClick={() => setOpen(false)}
                aria-label="Close"
                className="absolute right-4 top-4 z-20 flex h-9 w-9 items-center justify-center rounded-full bg-white/70 text-blush-600 transition hover:scale-110"
              >
                ✕
              </button>
              <div className="overflow-y-auto px-7 py-9 text-left sm:px-10">
                <div className="text-center">
                  <div className="mx-auto mb-4 text-5xl">🌹</div>
                  <h3 className="font-script text-4xl text-gradient">
                    My Dearest Love
                  </h3>
                </div>
                <p className="mt-5 font-serif text-[15px] leading-relaxed text-blush-800">
                  If you are reading this, then you've already made me the
                  luckiest soul alive. There aren't enough words in any language
                  to hold all that I feel for you — but I'll try, because you
                  deserve to know.
                </p>
                <p className="mt-4 font-serif text-[15px] leading-relaxed text-blush-800">
                  You are my calm in the chaos, my favourite hello and my hardest
                  goodbye. You taught my heart what 'home' truly means. With you,
                  ordinary moments become memories I'll carry forever — your
                  laugh echoing in quiet rooms, your hand finding mine without
                  even looking.
                </p>
                <p className="mt-4 font-serif text-[15px] leading-relaxed text-blush-800">
                  So here is my promise: to choose you, on the good days and the
                  messy ones, for as long as my heart keeps beating — and maybe
                  even after. Forever isn't long enough, but it's a beautiful
                  place to start.
                </p>
                <p className="mt-6 text-right font-dancing text-2xl text-rose-gold">
                  Yours, always and entirely 💗
                </p>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
}

import { useEffect, useRef } from "react";
import { motion } from "framer-motion";
import confetti from "canvas-confetti";
import couple from "@/assets/couple.jpg";

const BURST_COLORS = ["#ff5d8f", "#ff8fb1", "#ff3d6e", "#ffd6e8", "#b76e79", "#ffe066"];

type Particle = {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  max: number;
  color: string;
  size: number;
};

type Rocket = { x: number; y: number; vx: number; vy: number; color: string };

type FloatHeart = {
  x: number;
  y: number;
  size: number;
  speed: number;
  sway: number;
  rot: number;
  vr: number;
  alpha: number;
  color: string;
};

function drawHeart(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  size: number,
  color: string,
  alpha: number
) {
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(size, size);
  ctx.globalAlpha = alpha;
  ctx.fillStyle = color;
  ctx.beginPath();
  ctx.moveTo(0, 0.28);
  ctx.bezierCurveTo(0, 0, -0.5, 0, -0.5, 0.28);
  ctx.bezierCurveTo(-0.5, 0.55, 0, 0.72, 0, 0.96);
  ctx.bezierCurveTo(0, 0.72, 0.5, 0.55, 0.5, 0.28);
  ctx.bezierCurveTo(0.5, 0, 0, 0, 0, 0.28);
  ctx.closePath();
  ctx.fill();
  ctx.restore();
}

/** Full-screen celebration: heart-shaped fireworks, raining hearts & confetti. */
export default function Celebration({ onClose }: { onClose: () => void }) {
  const ref = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    let w = 0;
    let h = 0;
    let raf = 0;
    const rand = (a: number, b: number) => a + Math.random() * (b - a);
    const pick = <T,>(arr: T[]) => arr[Math.floor(Math.random() * arr.length)];

    const particles: Particle[] = [];
    const rockets: Rocket[] = [];
    const hearts: FloatHeart[] = [];

    const resize = () => {
      w = window.innerWidth;
      h = window.innerHeight;
      canvas.width = w * dpr;
      canvas.height = h * dpr;
      canvas.style.width = w + "px";
      canvas.style.height = h + "px";
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };

    const spawnHearts = () => {
      while (hearts.length < 90) {
        hearts.push({
          x: Math.random() * w,
          y: rand(0, h) + h * 0.2,
          size: rand(6, 20),
          speed: rand(0.6, 2.2),
          sway: Math.random() * Math.PI * 2,
          rot: rand(-0.4, 0.4),
          vr: rand(-0.02, 0.02),
          alpha: rand(0.4, 0.9),
          color: pick(BURST_COLORS),
        });
      }
    };

    const launchRocket = () => {
      rockets.push({
        x: rand(w * 0.15, w * 0.85),
        y: h + 10,
        vx: rand(-0.6, 0.6),
        vy: -rand(8, 11),
        color: pick(BURST_COLORS),
      });
    };

    const explode = (x: number, y: number, color: string) => {
      const n = 48;
      for (let i = 0; i < n; i++) {
        const t = (i / n) * Math.PI * 2;
        const hx = 16 * Math.pow(Math.sin(t), 3);
        const hy = -(13 * Math.cos(t) - 5 * Math.cos(2 * t) - 2 * Math.cos(3 * t) - Math.cos(4 * t));
        const j = rand(0.85, 1.15);
        particles.push({
          x,
          y,
          vx: hx * 0.22 * j + rand(-0.3, 0.3),
          vy: hy * 0.22 * j + rand(-0.3, 0.3),
          life: rand(60, 110),
          max: 110,
          color,
          size: rand(1.6, 3.2),
        });
      }
    };

    let lastRocket = 0;
    const frame = (t: number) => {
      ctx.clearRect(0, 0, w, h);
      ctx.globalCompositeOperation = "lighter";

      if (t - lastRocket > 700) {
        lastRocket = t;
        launchRocket();
      }

      for (let i = rockets.length - 1; i >= 0; i--) {
        const r = rockets[i];
        r.x += r.vx;
        r.y += r.vy;
        r.vy += 0.12;
        ctx.globalAlpha = 1;
        ctx.fillStyle = r.color;
        ctx.beginPath();
        ctx.arc(r.x, r.y, 2.4, 0, Math.PI * 2);
        ctx.fill();
        if (r.vy >= 0) {
          explode(r.x, r.y, r.color);
          rockets.splice(i, 1);
        }
      }

      for (let i = particles.length - 1; i >= 0; i--) {
        const p = particles[i];
        p.x += p.vx;
        p.y += p.vy;
        p.vy += 0.035;
        p.vx *= 0.99;
        p.life--;
        const a = Math.max(0, p.life / p.max);
        ctx.globalAlpha = a;
        ctx.fillStyle = p.color;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fill();
        if (p.life <= 0) particles.splice(i, 1);
      }

      // raining glowing hearts
      for (const ht of hearts) {
        ht.y -= ht.speed;
        ht.sway += 0.02;
        ht.x += Math.sin(ht.sway) * 0.6;
        ht.rot += ht.vr;
        if (ht.y < -30) {
          ht.y = h + 30;
          ht.x = Math.random() * w;
        }
        ctx.save();
        ctx.rotate(ht.rot);
        ctx.globalAlpha = ht.alpha;
        drawHeart(ctx, ht.x, ht.y, ht.size, ht.color, ht.alpha);
        ctx.restore();
      }

      ctx.globalCompositeOperation = "source-over";
      ctx.globalAlpha = 1;
      raf = requestAnimationFrame(frame);
    };

    resize();
    spawnHearts();
    launchRocket();
    raf = requestAnimationFrame(frame);
    window.addEventListener("resize", resize);
    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("resize", resize);
    };
  }, []);

  // confetti bursts (hearts + sparkle)
  useEffect(() => {
    const heart = confetti.shapeFromText({ text: "❤️", scalar: 2.2 });
    const burst = () => {
      confetti({
        particleCount: 28,
        spread: 70,
        startVelocity: 45,
        origin: { x: Math.random(), y: Math.random() * 0.4 + 0.1 },
        scalar: 1.5,
        shapes: [heart],
        colors: BURST_COLORS,
        ticks: 220,
      });
      confetti({
        particleCount: 18,
        spread: 100,
        startVelocity: 35,
        origin: { x: Math.random(), y: Math.random() * 0.4 + 0.1 },
        colors: ["#ffffff", "#ffd6e8", "#ffe066"],
        ticks: 180,
      });
    };
    burst();
    const id = setInterval(burst, 900);
    return () => clearInterval(id);
  }, []);

  return (
    <motion.div
      className="fixed inset-0 z-[80] flex items-center justify-center overflow-hidden p-4"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
    >
      <div className="absolute inset-0 bg-gradient-to-b from-rose-50/60 via-blush-100/50 to-white/70" />
      <canvas ref={ref} className="absolute inset-0" style={{ pointerEvents: "none" }} />

      <motion.div
        initial={{ opacity: 0, scale: 0.8, y: 30 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        transition={{ delay: 0.3, type: "spring", stiffness: 200, damping: 18 }}
        className="glass-strong relative z-10 w-full max-w-md rounded-[2rem] p-6 text-center sm:p-9"
      >
        <motion.img
          src={couple}
          alt="A couple in love"
          initial={{ scale: 0.6, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ delay: 0.5, type: "spring", stiffness: 180, damping: 14 }}
          className="mx-auto mb-4 h-40 w-40 rounded-full border-4 border-white object-cover shadow-2xl sm:h-48 sm:w-48"
        />
        <motion.div
          animate={{ scale: [1, 1.08, 1] }}
          transition={{ duration: 1.2, repeat: Infinity }}
          className="mb-2 text-4xl"
        >
          🎉💖🎉
        </motion.div>
        <h2 className="font-script text-4xl leading-tight text-gradient sm:text-5xl">
          Yay! Our love story begins forever ❤️✨
        </h2>
        <p className="mx-auto mt-3 max-w-xs font-serif text-[15px] leading-relaxed text-blush-800">
          You just made me the happiest person in the entire universe. This is
          the start of our forever — and I promise to love you every single day.
        </p>
        <button
          onClick={onClose}
          className="mt-6 rounded-full bg-gradient-to-r from-blush-500 to-rose-gold px-8 py-3.5 font-semibold text-white shadow-xl transition-transform duration-300 hover:scale-105 active:scale-95"
        >
          Let's celebrate together 💕
        </button>
      </motion.div>
    </motion.div>
  );
}

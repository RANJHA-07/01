import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { useAudio } from "@/context/AudioContext";
import Typewriter from "@/components/Typewriter";
import NoButton from "@/components/NoButton";
import Celebration from "@/components/Celebration";
import LoveCountdown from "@/components/LoveCountdown";
import PhotoGallery from "@/components/PhotoGallery";
import Reasons from "@/components/Reasons";
import SecretLetter from "@/components/SecretLetter";

const LETTER =
  "From the moment you came into my life, every day became more beautiful. Your smile is my happiness, your presence is my peace. Will you stay with me forever?";

export default function ProposalPage({ userName }: { userName: string }) {
  const { setCheerful } = useAudio();
  const [saidYes, setSaidYes] = useState(false);
  const [celebrate, setCelebrate] = useState(false);

  const sayYes = () => {
    setSaidYes(true);
    setCelebrate(true);
    setCheerful();
  };

  return (
    <motion.div
      key="proposal"
      initial={{ opacity: 0, scale: 0.98 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.7 }}
      className="relative"
    >
      {/* ---------- HERO ---------- */}
      <section className="relative flex min-h-screen flex-col items-center justify-center px-5 py-24 text-center">
        <motion.p
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="font-dancing text-2xl text-rose-gold sm:text-3xl"
        >
          Dearest {userName},
        </motion.p>

        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.35, duration: 0.8 }}
          className="mt-2 max-w-4xl font-script text-[2.7rem] leading-[1.1] text-gradient sm:text-7xl"
        >
          Will You Be Mine Forever?
          <span className="ml-2 inline-block animate-heartbeat">❤️</span>
        </motion.h1>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.7, duration: 0.8 }}
          className="glass mt-8 max-w-2xl rounded-3xl px-6 py-6 sm:px-10 sm:py-8"
        >
          <p className="min-h-[5.5rem] font-serif text-base leading-relaxed text-blush-800 sm:min-h-[4rem] sm:text-lg">
            <Typewriter text={LETTER} speed={38} startDelay={900} />
          </p>
        </motion.div>

        {/* Buttons */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 2.4, duration: 0.6 }}
          className="mt-10 flex w-full max-w-md flex-col items-center gap-6"
        >
          {!saidYes ? (
            <div className="flex w-full flex-col items-center justify-center gap-5 sm:flex-row sm:items-center">
              <motion.button
                onClick={sayYes}
                whileHover={{ scale: 1.08 }}
                whileTap={{ scale: 0.94 }}
                animate={{ boxShadow: ["0 0 0 0 rgba(244,63,120,0.45)", "0 0 0 16px rgba(244,63,120,0)", "0 0 0 0 rgba(244,63,120,0.45)"] }}
                transition={{ boxShadow: { duration: 1.8, repeat: Infinity } }}
                className="rounded-full bg-gradient-to-r from-blush-500 via-blush-400 to-rose-gold px-12 py-5 text-2xl font-bold text-white shadow-2xl shadow-blush-300/70"
              >
                💖 YES
              </motion.button>
              <NoButton />
            </div>
          ) : (
            <motion.div
              initial={{ scale: 0.7, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="flex flex-col items-center gap-3"
            >
              <p className="font-dancing text-3xl text-blush-600">
                You said YES! 💍✨
              </p>
              <button
                onClick={() => setCelebrate(true)}
                className="rounded-full glass-strong px-6 py-3 font-semibold text-blush-700 transition hover:scale-105"
              >
                Celebrate again 🎉
              </button>
            </motion.div>
          )}
        </motion.div>

        {/* scroll hint */}
        {!saidYes && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 3 }}
            className="absolute bottom-6 flex flex-col items-center text-blush-500"
          >
            <span className="text-xs uppercase tracking-[0.2em]">scroll for more</span>
            <motion.span
              animate={{ y: [0, 8, 0] }}
              transition={{ duration: 1.4, repeat: Infinity }}
              className="mt-1 text-xl"
            >
              ↓
            </motion.span>
          </motion.div>
        )}
      </section>

      <LoveCountdown />
      <PhotoGallery />
      <Reasons />
      <SecretLetter />

      <footer className="py-12 text-center">
        <p className="font-script text-3xl text-gradient">Forever &amp; always</p>
        <p className="mt-2 text-sm text-blush-700/70">
          Made with endless love, just for you 💗
        </p>
      </footer>

      <AnimatePresence>
        {celebrate && <Celebration onClose={() => setCelebrate(false)} />}
      </AnimatePresence>
    </motion.div>
  );
}

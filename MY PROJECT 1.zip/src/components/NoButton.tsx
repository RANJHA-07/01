import { useEffect, useRef, useState } from "react";
import { motion } from "framer-motion";

const TEASES = [
  "Are you sure? 🥺",
  "Think again ❤️",
  "My heart will be sad 😭",
  "Please give love a chance 🌹",
  "Nooo, not that one! 🙈",
  "You can't catch me 😜",
  "Love me instead? 💗",
];

/** A "NO" button that playfully runs away from the cursor, shrinks, and teases. */
export default function NoButton() {
  const [pos, setPos] = useState({ x: 0, y: 0 });
  const [scale, setScale] = useState(1);
  const [rotate, setRotate] = useState(0);
  const [tease, setTease] = useState(TEASES[0]);
  const [escaped, setEscaped] = useState(0);
  const [mounted, setMounted] = useState(false);
  const btnRef = useRef<HTMLButtonElement>(null);
  const lastMove = useRef(0);

  const flee = () => {
    const pad = 24;
    const maxX = window.innerWidth - 150;
    const maxY = window.innerHeight - 120;
    setPos({
      x: Math.random() * (maxX - pad) + pad - maxX / 2,
      y: Math.random() * (maxY - pad) + pad - maxY / 2,
    });
    setScale((s) => Math.max(0.55, s - 0.07));
    setRotate(Math.random() * 60 - 30);
    setTease(TEASES[Math.floor(Math.random() * TEASES.length)]);
    setEscaped((e) => e + 1);
  };

  useEffect(() => {
    setMounted(true);
    const onMove = (e: MouseEvent) => {
      const btn = btnRef.current;
      if (!btn) return;
      const r = btn.getBoundingClientRect();
      const cx = r.left + r.width / 2;
      const cy = r.top + r.height / 2;
      const dist = Math.hypot(e.clientX - cx, e.clientY - cy);
      const now = performance.now();
      if (dist < 120 && now - lastMove.current > 180) {
        lastMove.current = now;
        flee();
      }
    };
    window.addEventListener("mousemove", onMove);
    return () => window.removeEventListener("mousemove", onMove);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div className="relative flex h-[88px] items-center justify-center">
      <motion.span
        key={tease}
        initial={{ opacity: 0, y: 6, scale: 0.9 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        className="pointer-events-none absolute -top-2 whitespace-nowrap rounded-full glass px-3 py-1 text-sm font-semibold text-blush-700"
      >
        {tease}
      </motion.span>

      <motion.button
        ref={btnRef}
        type="button"
        onClick={flee}
        animate={mounted ? { x: pos.x, y: pos.y, scale, rotate } : {}}
        transition={{ type: "spring", stiffness: 320, damping: 18 }}
        className="relative rounded-full border border-blush-300 bg-white/70 px-8 py-4 font-semibold text-blush-600 shadow-lg backdrop-blur"
      >
        No 😢
      </motion.button>

      {escaped >= 5 && (
        <span className="absolute -bottom-1 text-xs text-rose-gold">
          (spoiler: there's no escape, just say yes 💕)
        </span>
      )}
    </div>
  );
}

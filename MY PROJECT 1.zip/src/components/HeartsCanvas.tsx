import { useEffect, useRef } from "react";

type Props = {
  count?: number;
  sparkleCount?: number;
  className?: string;
};

type Heart = {
  x: number;
  y: number;
  size: number;
  speed: number;
  sway: number;
  swaySpeed: number;
  rot: number;
  vr: number;
  alpha: number;
  color: string;
};

type Spark = {
  x: number;
  y: number;
  r: number;
  tw: number;
  ts: number;
  drift: number;
  color: string;
};

const HEART_COLORS = [
  "#ff5d8f",
  "#ff8fb1",
  "#ff3d6e",
  "#ffc2d1",
  "#e75480",
  "#b76e79",
  "#ffd6e8",
];
const SPARK_COLORS = ["#ffffff", "#ffe6f0", "#ffd0e0", "#fff0c2"];

function drawHeart(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  size: number,
  color: string,
  alpha: number
) {
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(size, size);
  ctx.globalAlpha = alpha;
  ctx.shadowColor = color;
  ctx.shadowBlur = 12;
  ctx.fillStyle = color;
  ctx.beginPath();
  ctx.moveTo(0, 0.28);
  ctx.bezierCurveTo(0, 0, -0.5, 0, -0.5, 0.28);
  ctx.bezierCurveTo(-0.5, 0.55, 0, 0.72, 0, 0.96);
  ctx.bezierCurveTo(0, 0.72, 0.5, 0.55, 0.5, 0.28);
  ctx.bezierCurveTo(0.5, 0, 0, 0, 0, 0.28);
  ctx.closePath();
  ctx.fill();
  ctx.restore();
}

/** Full-screen animated background of floating glowing hearts + twinkling sparkles. */
export default function HeartsCanvas({
  count = 26,
  sparkleCount = 42,
  className,
}: Props) {
  const ref = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let w = 0;
    let h = 0;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    let hearts: Heart[] = [];
    let sparks: Spark[] = [];
    let raf = 0;

    const rand = (a: number, b: number) => a + Math.random() * (b - a);

    const buildHearts = () => {
      hearts = Array.from({ length: count }, () => ({
        x: Math.random() * w,
        y: Math.random() * h,
        size: rand(7, 22),
        speed: rand(0.25, 0.95),
        sway: Math.random() * Math.PI * 2,
        swaySpeed: rand(0.4, 1.1),
        rot: rand(-0.3, 0.3),
        vr: rand(-0.012, 0.012),
        alpha: rand(0.35, 0.85),
        color: HEART_COLORS[Math.floor(Math.random() * HEART_COLORS.length)],
      }));
    };

    const buildSparks = () => {
      sparks = Array.from({ length: sparkleCount }, () => ({
        x: Math.random() * w,
        y: Math.random() * h,
        r: rand(0.8, 2.6),
        tw: Math.random() * Math.PI * 2,
        ts: rand(0.02, 0.06),
        drift: rand(-0.15, 0.15),
        color: SPARK_COLORS[Math.floor(Math.random() * SPARK_COLORS.length)],
      }));
    };

    const resize = () => {
      w = window.innerWidth;
      h = window.innerHeight;
      canvas.width = w * dpr;
      canvas.height = h * dpr;
      canvas.style.width = w + "px";
      canvas.style.height = h + "px";
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      buildHearts();
      buildSparks();
    };

    const frame = () => {
      ctx.clearRect(0, 0, w, h);

      for (const p of hearts) {
        p.y -= p.speed;
        p.sway += 0.01 * p.swaySpeed;
        p.x += Math.sin(p.sway) * 0.5;
        p.rot += p.vr;
        if (p.y < -30) {
          p.y = h + 30;
          p.x = Math.random() * w;
        }
        ctx.save();
        ctx.rotate(p.rot);
        drawHeart(ctx, p.x, p.y, p.size, p.color, p.alpha);
        ctx.restore();
      }

      for (const s of sparks) {
        s.tw += s.ts;
        s.y += s.drift;
        if (s.y < -5) s.y = h + 5;
        const a = 0.2 + (Math.sin(s.tw) + 1) * 0.4;
        ctx.save();
        ctx.globalAlpha = a;
        ctx.shadowColor = s.color;
        ctx.shadowBlur = 8;
        ctx.fillStyle = s.color;
        ctx.beginPath();
        ctx.arc(s.x, s.y, s.r, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      }

      raf = requestAnimationFrame(frame);
    };

    resize();
    raf = requestAnimationFrame(frame);
    window.addEventListener("resize", resize);
    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("resize", resize);
    };
  }, [count, sparkleCount]);

  return (
    <canvas
      ref={ref}
      aria-hidden="true"
      className={className}
      style={{ pointerEvents: "none" }}
    />
  );
}

import { motion } from "framer-motion";

const REASONS = [
  {
    emoji: "😊",
    title: "Your Smile",
    text: "It turns my greyest days into sunshine and makes my whole world glow.",
  },
  {
    emoji: "❤️",
    title: "Your Kindness",
    text: "The gentle way you treat everyone proves how beautiful your soul is.",
  },
  {
    emoji: "🌹",
    title: "Your Caring Heart",
    text: "You notice the little things and love me in ways I never knew I needed.",
  },
  {
    emoji: "✨",
    title: "Every Moment",
    text: "Ordinary seconds become magical adventures the second you're beside me.",
  },
  {
    emoji: "🎶",
    title: "Your Laugh",
    text: "It's the melody I never want to stop hearing for the rest of my life.",
  },
  {
    emoji: "🌙",
    title: "Your Patience",
    text: "You calm my storms and make me believe in forever, one day at a time.",
  },
];

/** Animated "Reasons Why I Love You" cards that reveal on scroll. */
export default function Reasons() {
  return (
    <section className="relative mx-auto max-w-6xl px-5 py-20 sm:py-28">
      <div className="text-center">
        <p className="font-dancing text-2xl text-rose-gold sm:text-3xl">
          A few of the countless
        </p>
        <h2 className="mt-1 font-script text-4xl text-gradient sm:text-6xl">
          Reasons I Love You
        </h2>
      </div>

      <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {REASONS.map((r, i) => (
          <motion.div
            key={r.title}
            initial={{ opacity: 0, y: 50, rotateX: -8 }}
            whileInView={{ opacity: 1, y: 0, rotateX: 0 }}
            viewport={{ once: true, amount: 0.3 }}
            transition={{ duration: 0.6, delay: i * 0.08 }}
            whileHover={{ y: -8, scale: 1.03 }}
            className="group glass relative overflow-hidden rounded-3xl p-7 text-center"
          >
            <div className="pointer-events-none absolute -right-6 -top-6 h-24 w-24 rounded-full bg-blush-200/50 blur-2xl transition-transform duration-500 group-hover:scale-150" />
            <div className="relative mb-4 text-5xl transition-transform duration-300 group-hover:scale-125 group-hover:-rotate-6">
              {r.emoji}
            </div>
            <h3 className="relative font-serif text-xl font-bold text-blush-700">
              {r.title}
            </h3>
            <p className="relative mt-2 text-sm leading-relaxed text-blush-700/80">
              {r.text}
            </p>
          </motion.div>
        ))}
      </div>
    </section>
  );
}

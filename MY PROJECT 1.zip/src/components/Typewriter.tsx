import { useEffect, useRef, useState } from "react";

type Props = {
  text: string;
  speed?: number;
  className?: string;
  onDone?: () => void;
  startDelay?: number;
};

/** Types out text character-by-character with a blinking cursor. */
export default function Typewriter({
  text,
  speed = 42,
  className,
  onDone,
  startDelay = 0,
}: Props) {
  const [out, setOut] = useState("");
  const [done, setDone] = useState(false);
  const doneRef = useRef(onDone);
  doneRef.current = onDone;

  useEffect(() => {
    setOut("");
    setDone(false);
    let i = 0;
    let interval: ReturnType<typeof setInterval>;

    const timeout = setTimeout(() => {
      interval = setInterval(() => {
        i++;
        setOut(text.slice(0, i));
        if (i >= text.length) {
          clearInterval(interval);
          setDone(true);
          doneRef.current?.();
        }
      }, speed);
    }, startDelay);

    return () => {
      clearTimeout(timeout);
      clearInterval(interval);
    };
  }, [text, speed, startDelay]);

  return (
    <span className={className}>
      {out}
      {!done && <span className="cursor-blink font-bold text-blush-500">|</span>}
    </span>
  );
}

import { useCallback, useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";

type Burst = {
  id: number;
  x: number;
  y: number;
  dx: number;
  dy: number;
  rot: number;
  emoji: string;
  size: number;
};

const EMOJIS = ["💕", "❤️", "💖", "✨", "🌸", "💗"];
let counter = 0;

/** Spawns a tiny burst of floating hearts at every click — a little magic everywhere. */
export default function ClickHearts() {
  const [bursts, setBursts] = useState<Burst[]>([]);

  const spawn = useCallback((x: number, y: number) => {
    const n = 4 + Math.floor(Math.random() * 3);
    const next: Burst[] = [];
    for (let i = 0; i < n; i++) {
      const id = counter++;
      next.push({
        id,
        x,
        y,
        dx: (Math.random() - 0.5) * 120,
        dy: -60 - Math.random() * 90,
        rot: (Math.random() - 0.5) * 120,
        emoji: EMOJIS[Math.floor(Math.random() * EMOJIS.length)],
        size: 16 + Math.random() * 18,
      });
    }
    setBursts((b) => [...b, ...next]);
    const ids = next.map((n) => n.id);
    setTimeout(() => {
      setBursts((b) => b.filter((p) => !ids.includes(p.id)));
    }, 1100);
  }, []);

  useEffect(() => {
    const onClick = (e: MouseEvent) => spawn(e.clientX, e.clientY);
    const onTouch = (e: TouchEvent) => {
      const t = e.changedTouches[0];
      if (t) spawn(t.clientX, t.clientY);
    };
    window.addEventListener("click", onClick);
    window.addEventListener("touchstart", onTouch, { passive: true });
    return () => {
      window.removeEventListener("click", onClick);
      window.removeEventListener("touchstart", onTouch);
    };
  }, [spawn]);

  return (
    <div className="pointer-events-none fixed inset-0 z-[45] overflow-hidden">
      <AnimatePresence>
        {bursts.map((b) => (
          <motion.span
            key={b.id}
            initial={{ opacity: 1, x: 0, y: 0, scale: 0.4, rotate: 0 }}
            animate={{ opacity: 0, x: b.dx, y: b.dy, scale: 1.1, rotate: b.rot }}
            exit={{ opacity: 0 }}
            transition={{ duration: 1, ease: "easeOut" }}
            style={{ left: b.x, top: b.y, fontSize: b.size }}
            className="absolute -translate-x-1/2 -translate-y-1/2"
          >
            {b.emoji}
          </motion.span>
        ))}
      </AnimatePresence>
    </div>
  );
}

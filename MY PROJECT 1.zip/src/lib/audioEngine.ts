// A small, self-contained romantic music engine built with the Web Audio API.
// No external audio files needed — everything is synthesized, so it works in a
// single-file build. Produces a soft pad + music-box arpeggio + sparkle melody
// with lush reverb. Supports a "cheerful" mood for the big YES moment.

export type Mood = "normal" | "cheerful";

const NOTE: Record<string, number> = {
  C3: 130.81, D3: 146.83, E3: 164.81, F3: 174.61, G3: 196.0, A3: 220.0, B3: 246.94,
  C4: 261.63, D4: 293.66, E4: 329.63, F4: 349.23, G4: 392.0, A4: 440.0, B4: 493.88,
  C5: 523.25, D5: 587.33, E5: 659.25, F5: 698.46, G5: 783.99, A5: 880.0, B5: 987.77,
  C6: 1046.5,
};

// I – V – vi – IV in C major (a timeless, warm progression)
const PROGRESSION: number[][] = [
  [NOTE.C3, NOTE.E3, NOTE.G3, NOTE.C4, NOTE.E4, NOTE.G4], // C
  [NOTE.G3, NOTE.B3, NOTE.D4, NOTE.G4, NOTE.B4, NOTE.D5], // G
  [NOTE.A3, NOTE.C4, NOTE.E4, NOTE.A4, NOTE.C5, NOTE.E5], // Am
  [NOTE.F3, NOTE.A3, NOTE.C4, NOTE.F4, NOTE.A4, NOTE.C5], // F
];

type ToneOpt = {
  type: OscillatorType;
  peak: number;
  attack: number;
  release: number;
  wet: number;
};

export class RomanticAudio {
  private ctx: AudioContext | null = null;
  private master!: GainNode;
  private reverb!: ConvolverNode;
  private dry!: GainNode;
  private timer: ReturnType<typeof setTimeout> | null = null;
  private nextTime = 0;
  private step = 0;
  private mood: Mood = "normal";
  private started = false;

  get isStarted() {
    return this.started;
  }

  private ensure() {
    if (this.ctx) return;
    const Ctx =
      window.AudioContext ||
      (window as unknown as { webkitAudioContext: typeof AudioContext })
        .webkitAudioContext;
    this.ctx = new Ctx();

    this.master = this.ctx.createGain();
    this.master.gain.value = 0.0001;
    this.master.connect(this.ctx.destination);

    this.dry = this.ctx.createGain();
    this.dry.gain.value = 0.9;
    this.dry.connect(this.master);

    this.reverb = this.ctx.createConvolver();
    this.reverb.buffer = this.makeImpulse(2.8, 2.6);
    const wet = this.ctx.createGain();
    wet.gain.value = 0.55;
    this.reverb.connect(wet).connect(this.master);
  }

  private makeImpulse(duration: number, decay: number) {
    const ctx = this.ctx!;
    const length = Math.floor(ctx.sampleRate * duration);
    const impulse = ctx.createBuffer(2, length, ctx.sampleRate);
    for (let c = 0; c < 2; c++) {
      const data = impulse.getChannelData(c);
      for (let i = 0; i < length; i++) {
        data[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / length, decay);
      }
    }
    return impulse;
  }

  async start() {
    this.ensure();
    const ctx = this.ctx!;
    if (ctx.state === "suspended") {
      try {
        await ctx.resume();
      } catch {
        /* ignore */
      }
    }
    // Already playing — just bring the volume back up.
    if (this.started) {
      this.master.gain.cancelScheduledValues(ctx.currentTime);
      this.master.gain.linearRampToValueAtTime(0.4, ctx.currentTime + 1.0);
      return;
    }
    this.started = true;
    this.master.gain.cancelScheduledValues(ctx.currentTime);
    this.master.gain.setValueAtTime(Math.max(this.master.gain.value, 0.0001), ctx.currentTime);
    this.master.gain.linearRampToValueAtTime(0.4, ctx.currentTime + 1.3);
    this.nextTime = ctx.currentTime + 0.14;
    this.step = 0;
    this.scheduler();
  }

  stop() {
    if (!this.ctx) return;
    const ctx = this.ctx;
    this.started = false;
    if (this.timer) {
      clearTimeout(this.timer);
      this.timer = null;
    }
    this.master.gain.cancelScheduledValues(ctx.currentTime);
    this.master.gain.setValueAtTime(this.master.gain.value, ctx.currentTime);
    this.master.gain.linearRampToValueAtTime(0.0001, ctx.currentTime + 0.7);
  }

  setMood(mood: Mood) {
    this.mood = mood;
  }

  private scheduler = () => {
    if (!this.ctx || !this.started) return;
    const ctx = this.ctx;
    const bar = this.mood === "cheerful" ? 2.7 : 4.2;
    while (this.nextTime < ctx.currentTime + 1.1) {
      this.scheduleBar(this.step % PROGRESSION.length, this.nextTime, bar);
      this.nextTime += bar;
      this.step++;
    }
    this.timer = setTimeout(this.scheduler, 30);
  };

  private scheduleBar(idx: number, t: number, bar: number) {
    const chord = PROGRESSION[idx];
    const cheerful = this.mood === "cheerful";

    // Warm bass
    this.tone(chord[0] / 2, t, bar * 0.94, {
      type: "sine",
      peak: 0.16,
      attack: 0.6,
      release: 1.2,
      wet: 0.35,
    });

    // Soft sustained pad (root, third, fifth)
    [chord[0], chord[1], chord[2]].forEach((f) =>
      this.tone(f, t + 0.02, bar * 0.92, {
        type: "triangle",
        peak: 0.05,
        attack: 0.95,
        release: 1.4,
        wet: 0.7,
      })
    );

    // Music-box arpeggio
    const arp = [chord[3], chord[4], chord[5], chord[4]];
    const steps = cheerful ? 12 : 8;
    const stepDur = bar / steps;
    for (let i = 0; i < steps; i++) {
      const note = arp[i % arp.length] * (cheerful && i % 2 === 1 ? 2 : 1);
      this.tone(note, t + i * stepDur, stepDur * 2.4, {
        type: "sine",
        peak: cheerful ? 0.12 : 0.075,
        attack: 0.008,
        release: 0.9,
        wet: 0.85,
      });
    }

    // Sparkle melody
    const melChance = cheerful ? 0.95 : 0.6;
    if (Math.random() < melChance) {
      const choices = [chord[5], chord[4] * 2, chord[5] * 2, chord[3] * 2];
      const mel = choices[Math.floor(Math.random() * choices.length)];
      const mt = t + bar * (0.25 + Math.random() * 0.5);
      this.tone(mel, mt, 1.5, {
        type: "sine",
        peak: cheerful ? 0.11 : 0.08,
        attack: 0.02,
        release: 1.3,
        wet: 0.9,
      });
    }
  }

  private tone(freq: number, t: number, dur: number, opt: ToneOpt) {
    const ctx = this.ctx!;
    const osc = ctx.createOscillator();
    const g = ctx.createGain();
    osc.type = opt.type;
    osc.frequency.value = freq;
    g.gain.setValueAtTime(0.0001, t);
    g.gain.linearRampToValueAtTime(opt.peak, t + opt.attack);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    osc.connect(g);
    g.connect(this.dry);
    const send = ctx.createGain();
    send.gain.value = opt.wet;
    g.connect(send);
    send.connect(this.reverb);
    osc.start(t);
    osc.stop(t + dur + 0.25);
  }
}

export const romanticAudio = new RomanticAudio();

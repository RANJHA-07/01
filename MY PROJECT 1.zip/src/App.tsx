import { useState } from "react";
import { AnimatePresence } from "framer-motion";
import { AudioProvider } from "@/context/AudioContext";
import HeartsCanvas from "@/components/HeartsCanvas";
import MusicToggle from "@/components/MusicToggle";
import ClickHearts from "@/components/ClickHearts";
import LoginPage from "@/components/LoginPage";
import ProposalPage from "@/components/ProposalPage";

export default function App() {
  const [showPopup, setShowPopup] = useState(true);

  const [loggedIn, setLoggedIn] = useState(
    () => sessionStorage.getItem("fwy_logged") === "1"
  );

  const [userName, setUserName] = useState(
    () => sessionStorage.getItem("fwy_user") || "My Love"
  );

  const handleLogin = (name: string) => {
    sessionStorage.setItem("fwy_logged", "1");
    sessionStorage.setItem("fwy_user", name);
    setUserName(name);
    setLoggedIn(true);
  };

  return (
    <AudioProvider>
      {showPopup && (
        <div
          className="fixed inset-0 z-[9999] flex items-center justify-center bg-black/70"
          onClick={() => setShowPopup(false)}
        >
          <div className="mx-4 max-w-sm rounded-3xl bg-white p-6 text-center shadow-2xl">
            <h2 className="mb-3 text-3xl font-bold text-pink-600">
              ❤️ Welcome ❤️
            </h2>

            <p className="mb-5 text-gray-700">
              Tap anywhere to start our song 🎵
            </p>

            <button
              className="rounded-full bg-pink-500 px-6 py-3 font-semibold text-white"
              onClick={() => setShowPopup(false)}
            >
              Start Music 🎶
            </button>
          </div>
        </div>
      )}

      <div className="relative min-h-screen overflow-x-hidden">
        <div className="aurora pointer-events-none fixed inset-0 z-0 opacity-70" />
        <HeartsCanvas className="fixed inset-0 z-0 h-full w-full" />

        <main className="relative z-10">
          <AnimatePresence mode="wait">
            {loggedIn ? (
              <ProposalPage key="proposal" userName={userName} />
            ) : (
              <LoginPage key="login" onLogin={handleLogin} />
            )}
          </AnimatePresence>
        </main>

        <MusicToggle />
        <ClickHearts />
      </div>
    </AudioProvider>
  );
}
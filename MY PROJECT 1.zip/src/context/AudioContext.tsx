import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useRef,
  useState,
  type ReactNode,
} from "react";

import songFile from "@/assets/song.mp3";

type Mood = "normal" | "cheerful";

type AudioState = {
  playing: boolean;
  mood: Mood;
  toggle: () => void;
  play: () => void;
  setCheerful: () => void;
};

const AudioCtx = createContext<AudioState>({
  playing: false,
  mood: "normal",
  toggle: () => {},
  play: () => {},
  setCheerful: () => {},
});

export function AudioProvider({ children }: { children: ReactNode }) {
  const [playing, setPlaying] = useState(false);
  const [mood, setMood] = useState<Mood>("normal");

  const audioRef = useRef<HTMLAudioElement | null>(null);

  if (!audioRef.current) {
    audioRef.current = new Audio(songFile);
    audioRef.current.loop = true;
    audioRef.current.volume = 1;
  }

  const play = useCallback(async () => {
    try {
      await audioRef.current?.play();
      setPlaying(true);
    } catch (err) {
      console.error(err);
    }
  }, []);

  const toggle = useCallback(async () => {
    if (!audioRef.current) return;

    if (playing) {
      audioRef.current.pause();
      setPlaying(false);
    } else {
      try {
        await audioRef.current.play();
        setPlaying(true);
      } catch (err) {
        console.error(err);
      }
    }
  }, [playing]);

  const setCheerful = useCallback(() => {
    setMood("cheerful");
  }, []);

  useEffect(() => {
    const startMusic = async () => {
      if (!audioRef.current || playing) return;

      try {
        await audioRef.current.play();
        setPlaying(true);
      } catch (err) {
        console.error(err);
      }

      document.removeEventListener("click", startMusic);
      document.removeEventListener("touchstart", startMusic);
    };

    document.addEventListener("click", startMusic);
    document.addEventListener("touchstart", startMusic);

    return () => {
      document.removeEventListener("click", startMusic);
      document.removeEventListener("touchstart", startMusic);
    };
  }, [playing]);

  return (
    <AudioCtx.Provider
      value={{
        playing,
        mood,
        toggle,
        play,
        setCheerful,
      }}
    >
      {children}
    </AudioCtx.Provider>
  );
}

export const useAudio = () => useContext(AudioCtx);
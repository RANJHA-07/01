import {
  createContext,
  useCallback,
  useContext,
  useState,
  type ReactNode,
} from "react";
import { romanticAudio, type Mood } from "@/lib/audioEngine";

type AudioState = {
  playing: boolean;
  mood: Mood;
  toggle: () => void;
  play: () => void;
  setCheerful: () => void;
};

const AudioCtx = createContext<AudioState>({
  playing: false,
  mood: "normal",
  toggle: () => {},
  play: () => {},
  setCheerful: () => {},
});

export function AudioProvider({ children }: { children: ReactNode }) {
  const [playing, setPlaying] = useState(false);
  const [mood, setMood] = useState<Mood>("normal");

  const play = useCallback(() => {
    romanticAudio.start().then(() => setPlaying(true));
  }, []);

  const toggle = useCallback(() => {
    if (playing) {
      romanticAudio.stop();
      setPlaying(false);
    } else {
      romanticAudio.start().then(() => setPlaying(true));
    }
  }, [playing]);

  const setCheerful = useCallback(() => {
    romanticAudio.setMood("cheerful");
    setMood("cheerful");
    if (!playing) {
      romanticAudio.start().then(() => setPlaying(true));
    }
  }, [playing]);

  return (
    <AudioCtx.Provider value={{ playing, mood, toggle, play, setCheerful }}>
      {children}
    </AudioCtx.Provider>
  );
}

// eslint-disable-next-line react-refresh/only-export-components
export const useAudio = () => useContext(AudioCtx);

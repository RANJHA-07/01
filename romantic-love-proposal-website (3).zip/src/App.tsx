import { useState } from "react";
import { AnimatePresence } from "framer-motion";
import { AudioProvider } from "@/context/AudioContext";
import HeartsCanvas from "@/components/HeartsCanvas";
import MusicToggle from "@/components/MusicToggle";
import ClickHearts from "@/components/ClickHearts";
import LoginPage from "@/components/LoginPage";
import ProposalPage from "@/components/ProposalPage";

export default function App() {
  const [loggedIn, setLoggedIn] = useState(
    () => sessionStorage.getItem("fwy_logged") === "1"
  );
  const [userName, setUserName] = useState(
    () => sessionStorage.getItem("fwy_user") || "My Love"
  );

  const handleLogin = (name: string) => {
    sessionStorage.setItem("fwy_logged", "1");
    sessionStorage.setItem("fwy_user", name);
    setUserName(name);
    setLoggedIn(true);
  };

  return (
    <AudioProvider>
      <div className="relative min-h-screen overflow-x-hidden">
        {/* dreamy animated background layers */}
        <div className="aurora pointer-events-none fixed inset-0 z-0 opacity-70" />
        <HeartsCanvas className="fixed inset-0 z-0 h-full w-full" />

        <main className="relative z-10">
          <AnimatePresence mode="wait">
            {loggedIn ? (
              <ProposalPage key="proposal" userName={userName} />
            ) : (
              <LoginPage key="login" onLogin={handleLogin} />
            )}
          </AnimatePresence>
        </main>

        <MusicToggle />
        <ClickHearts />
      </div>
    </AudioProvider>
  );
}
